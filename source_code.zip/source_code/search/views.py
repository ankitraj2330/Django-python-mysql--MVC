from django.shortcuts import render
from django.http import HttpResponse, HttpResponseNotModified
from .models import AuthorsNew, Book, BookAuthors
from django.db import connection, transaction, DatabaseError, IntegrityError 
import datetime as dt
from datetime import datetime
from datetime import timedelta
from django.contrib import messages


# Create your views here.
# def index(request):
#      # return HttpResponse('Hello World!')
   
#     return render(request, 'search/index.html')

def index(request):
    if request.method == 'GET':
        return render(request, 'search/index.html')
    if request.method == 'POST':
        if request.POST.get('searching'):
            searchkey = request.POST.get('searching')
            searchBooks ='SELECT book.ISBN as isbn, book.Title as title, book.Availability as availability, group_concat(authors_new.Name separator", ") as "authors" \
            FROM book, authors_new, book_authors \
            WHERE book.ISBN = book_authors.ISBN AND book_authors.Author_id = authors_new.Author_id AND \
            (book.Title LIKE "%%' + searchkey + '%%" OR \
            authors_new.Name LIKE "%%' + searchkey + '%%" OR \
            book.ISBN LIKE "%%' + searchkey + '%%") GROUP BY book.ISBN'
            cursor = connection.cursor()
            cursor.execute(searchBooks)

            columns = [col[0] for col in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            due_date = datetime.today() + timedelta(days=14)
            due_date = due_date.strftime("%Y-%m-%d")
            return render(request, 'search/index.html', {'results':results, 'due': due_date})
        elif request.POST.get('card_id'):    
            card_id = request.POST.get('card_id')
            isbn = request.POST.get('isbn')
            date_out = request.POST.get('date_out')
            due_date = request.POST.get('due_date')
            checkLimit = "select count(borrower_id) as count from book_loans where borrower_id = '" + card_id + "' and date_in is null"
            cursor = connection.cursor()
            cursor.execute(checkLimit)
            
            res = cursor.fetchall()
            # res1= str(res[0])

            count = res[0][0]
        
            if (count<3):
                checkavailability = "select availability from book where ISBN='"+ isbn + "'"
                cursor.execute(checkavailability)
                a = cursor.fetchall()
                if(a[0][0]==0):
                   return HttpResponse("Book Unavailable") 
                insertLoan = "insert into book_loans(isbn, borrower_id, date_out, due_date) values('" + isbn + "' \
                , '" + card_id + "', '" + date_out + "', '" + due_date + "')"
                cursor.execute(insertLoan)
                modifyavailability = "update book set availability=0 where ISBN='"+ isbn + "'"
                cursor.execute(modifyavailability)
                return HttpResponse("Book checked out")
            else:
                return HttpResponse("Borrower has already taken 3 books")
            #     messages.add_message(request, messages.INFO, "success")
            # #    return render('search/index.html', message:'Save complete')
                # messages.add_message(request, messages.INFO, 'Hello world.')
                # return HttpResponse(messages.)
                            
def checkin(request):
    if request.method == 'GET':
        return render(request, 'search/checkin.html')
    if request.method == 'POST':
        if request.POST.get('searchingcheckin'):
            searchcheckinkey = request.POST.get('searchingcheckin')
            searchLoan ='SELECT book_loans.loan_id as loan_id, book_loans.ISBN as isbn, book_loans.Due_date as due_date , book.Title as title, \
            borroweroriginal.Borrower_id as b_id, concat(Borroweroriginal.Firstname, " " , Borroweroriginal.lastname) as "Borrower_Name" \
            FROM book, Borroweroriginal, book_loans \
            WHERE book.ISBN = book_loans.ISBN AND borroweroriginal.Borrower_id = book_loans.Borrower_id AND \
            (book_loans.ISBN LIKE "%%' + searchcheckinkey + '%%" OR \
            Borroweroriginal.Firstname LIKE "%%' + searchcheckinkey + '%%" OR \
            Borroweroriginal.lastname LIKE "%%' + searchcheckinkey + '%%" OR \
            book_loans.Borrower_id LIKE "%%' + searchcheckinkey + '%%")'
            cursor = connection.cursor()
            cursor.execute(searchLoan)

            columns = [col[0] for col in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]

            return render(request, 'search/checkin.html', {'results':results})
        else:
            loan_id = request.POST.get('loan_id')
            date_in = request.POST.get('date_in')

            getDateIn = "select date_in from book_loans where loan_id = " + loan_id
            cursor = connection.cursor()
            cursor.execute(getDateIn)
            date_in_exists = cursor.fetchall()
            # return HttpResponse(date_in_exists[0][0] is not None)

            if date_in_exists[0][0] is not None:
                return HttpResponse("Book is already checked in")
            else:
                getIsbn = "SELECT isbn FROM book_loans WHERE loan_id = '" + loan_id + "'"
                cursor.execute(getIsbn)
                result = cursor.fetchall()
                isbn = result[0][0]
                
                updateLoan = "UPDATE book_loans SET date_in = '" + date_in + "' WHERE loan_id = '" + loan_id + "'"
                cursor.execute(updateLoan)

                updateAvailability = "update book set availability=1 where ISBN='"+ isbn + "'"
                cursor.execute(updateAvailability)

                return HttpResponse("Book checked in")
                

def addborrower(request):
    if request.method == 'GET':
        return render(request, 'search/addborrower.html')
    if request.method == 'POST':
        fname = request.POST.get('firstName')
        lname = request.POST.get('lastName')
        ssn = request.POST.get('ssn')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        
        insertBorrower = "insert into borroweroriginal(firstname, lastname, ssn, phone, address, city, state) \
        values('" + fname + "','" + lname + "','" + ssn + "','" + phone + "','" + address + "','" + city + "','" + state + "')"
        cursor = connection.cursor()

        try:
            cursor.execute(insertBorrower)
        except (DatabaseError, IntegrityError) as e:
            return HttpResponse(e)
        else:
            return HttpResponse("Borrower registered")

def fines(request):
    if request.method == 'GET':
        return render(request, 'search/fines.html')
    if request.method == 'POST':
        if request.POST.get('fineType'):
            if request.POST.get('fineType') == "unpaid":
                getFines = "select bl.borrower_id as borrower_id, concat(firstname, ' ', lastname) as name, sum(fine_amt) as fine_amt \
                from fines f, borroweroriginal b, book_loans bl \
                where f.loan_id = bl.loan_id and bl.borrower_id = b.borrower_id and paid is null \
                group by bl.borrower_id" 
                fineType = "unpaid"
            elif request.POST.get('fineType') == "paid":
                getFines = "select bl.borrower_id as borrower_id, concat(firstname, ' ', lastname) as name, sum(fine_amt) as fine_amt \
                from fines f, borroweroriginal b, book_loans bl \
                where f.loan_id = bl.loan_id and bl.borrower_id = b.borrower_id and paid is not null \
                group by bl.borrower_id" 
                fineType = "paid"
            else:
                getFines = "select fines.loan_id as loan_id, book_loans.borrower_id as borrower_id, concat(firstname, ' ', lastname) as name, fine_amt, paid \
                from book_loans, fines, borroweroriginal where fines.loan_id = book_loans.loan_id and \
                borroweroriginal.borrower_id = book_loans.borrower_id"
                fineType = "all"

            cursor = connection.cursor()
            cursor.execute(getFines)
            columns = [col[0] for col in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]

            return render(request, 'search/fines.html', {'results':results, 'fineType':fineType})
        elif request.POST.get('loan_id'):
            loan_id = request.POST.get('loan_id')
            isBookReturned = "select date_in from book_loans where loan_id = '" + loan_id + "'"
            cursor = connection.cursor()
            cursor.execute(isBookReturned)
            checkin_date = cursor.fetchall()
            if checkin_date[0][0] is not None:
                updatePayment = "update fines set paid = 1 where loan_id = '" + loan_id + "'"
                try:
                    cursor.execute(updatePayment)
                except (DatabaseError, IntegrityError) as e:
                    return HttpResponse(e)
                else:
                    return HttpResponse("Payment for Loan ID - " + loan_id +" is updated")
            else:
                return HttpResponse("Please check in the book before making Payment.")
        else:
            updateFines = "insert into fines(loan_id, fine_amt) select * from \
            (select loan_id, datediff(case when date_in is null then curdate() else date_in end, due_date) * 0.25 as amt \
            from book_loans having amt > 0) as changes on duplicate key update \
            fine_amt = if(paid is null, changes.amt, fine_amt)"
            cursor = connection.cursor()
            try:
                cursor.execute(updateFines)
            except (DatabaseError, IntegrityError) as e:
                return HttpResponse(e)
            else:
                return HttpResponse("Fines table was updated")
            