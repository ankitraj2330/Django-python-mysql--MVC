from django.db import models

# class Search(models.Model):

class AuthorsNew(models.Model):
    author_id = models.AutoField(db_column='Author_id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=200, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'authors_new'


class Book(models.Model):
    isbn = models.CharField(db_column='ISBN', primary_key=True, max_length=20)  # Field name made lowercase.
    title = models.CharField(db_column='Title', max_length=500, blank=True, null=True)  # Field name made lowercase.
    availability = models.IntegerField(db_column='Availability', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'book'


class BookAuthors(models.Model):
    author = models.ForeignKey(AuthorsNew, models.DO_NOTHING, db_column='Author_id', primary_key=True)  # Field name made lowercase.
    isbn = models.ForeignKey(Book, models.DO_NOTHING, db_column='ISBN')  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'book_authors'
        unique_together = (('author', 'isbn'),)

class BookLoans(models.Model):
    loan_id = models.AutoField(db_column='Loan_id', primary_key=True)  # Field name made lowercase.
    isbn = models.ForeignKey(Book, models.DO_NOTHING, db_column='ISBN', blank=True, null=True)  # Field name made lowercase.
    borrower = models.ForeignKey('Borroweroriginal', models.DO_NOTHING, db_column='Borrower_id', blank=True, null=True)  # Field name made lowercase.
    date_out = models.DateField(db_column='Date_out', blank=True, null=True)  # Field name made lowercase.
    due_date = models.DateField(db_column='Due_date', blank=True, null=True)  # Field name made lowercase.
    date_in = models.DateField(db_column='Date_in', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'book_loans'


class Borroweroriginal(models.Model):
    borrower_id = models.IntegerField(db_column='Borrower_id', primary_key=True)  # Field name made lowercase.
    ssn = models.CharField(db_column='SSN', max_length=20, blank=True, null=True)  # Field name made lowercase.
    firstname = models.CharField(db_column='Firstname', max_length=200, blank=True, null=True)  # Field name made lowercase.
    lastname = models.CharField(max_length=200, blank=True, null=True)
    address = models.CharField(db_column='Address', max_length=500, blank=True, null=True)  # Field name made lowercase.
    city = models.CharField(max_length=200, blank=True, null=True)
    state = models.CharField(db_column='State', max_length=200, blank=True, null=True)  # Field name made lowercase.
    phone = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'borroweroriginal'








